#define FLOAT (1<<14)

int int_mul_float(int, int);
int float_add_int(int, int);
int int_sub_float(int, int);
int float_mul_float(int f1, int f2);
int float_div_float(int, int);
int float_add_float(int, int);
int float_sub_float(int, int);
int float_div_int(int, int);

int int_mul_float(int i, int f){
	return i * f;
}

int float_add_int(int f, int i){
	return f + i*FLOAT;
}

int int_sub_float(int i, int f){
	return i*FLOAT - f;
}

int float_mul_float(int f1, int f2){
	int64_t tmp = f1;
	tmp = tmp*f2/FLOAT;
	return (int)tmp;
}

int float_div_float(int f1, int f2){
	int64_t tmp = f1;
	tmp = tmp*FLOAT/f2;
	return (int)tmp;
}

int float_add_float(int f1, int f2){
	return f1 + f2;
}

int float_sub_float(int f1, int f2){
	return f1-f2;
}

int float_div_int(int f, int i){
	return f/i;
}
