#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);
struct lock filesys_lock;

	void
syscall_init (void) 
{
	lock_init(&filesys_lock); /* new */
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

	static void
syscall_handler (struct intr_frame *f) 
{
	switch (*(uint32_t *)(f->esp)){
		case SYS_HALT: 
			halt();
			break;
		case SYS_EXIT:
			check_vaddr(f->esp+4);
			exit(*(uint32_t *)(f->esp + 4));
			break;
		case SYS_EXEC:
			check_vaddr(f->esp+4);
			f->eax = exec((const char *)*(uint32_t *)(f->esp + 4));
			break;
		case SYS_WAIT:
			check_vaddr(f->esp+4);
			f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
			break;
		case SYS_READ:
			check_vaddr(f->esp+4);
			check_vaddr(f->esp+8);
			check_vaddr(f->esp+12);
			f->eax = read((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp+8), (unsigned)*((uint32_t *)(f->esp+12)));
			break;
		case SYS_WRITE:
	 		check_vaddr(f->esp+4);
			check_vaddr(f->esp+8);
			check_vaddr(f->esp+12);
			f->eax=write((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp+12)));
			break;
		/* project 2 */
		case SYS_CREATE:
			check_vaddr(f->esp+4);
			check_vaddr(f->esp+8);
			f->eax = create((const char *)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
			break;
		case SYS_REMOVE:
			check_vaddr(f->esp + 4);
			f->eax = remove((const char *)*(uint32_t *)(f->esp + 4));
			break;
		case SYS_OPEN:
			check_vaddr(f->esp+4);
			f->eax = open((const char*)*(uint32_t *)(f->esp + 4));
			break;
		case SYS_CLOSE:
			check_vaddr(f->esp + 4);
			close((int)*(uint32_t *)(f->esp+4));
			break;
		case SYS_FILESIZE:
			check_vaddr(f->esp+4);
			f->eax = filesize((int)*(uint32_t *)(f->esp + 4));
			break;
		case SYS_SEEK:
			check_vaddr(f->esp + 4);
			check_vaddr(f->esp + 8);
			seek((int)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp+8));
			break;
		case SYS_TELL:
			check_vaddr(f->esp+4);
			f->eax = tell((int)*(uint32_t *)(f->esp + 4));
			break;
		/* user defined system call */
		case SYS_FIBONACCI:
			check_vaddr(f->esp+4);
			f->eax = fibonacci((int)*(uint32_t *)(f->esp+4));
			break;
		case SYS_SUM_OF_FOUR_INT:
			check_vaddr(f->esp+4);
			check_vaddr(f->esp+8);
			check_vaddr(f->esp+12);
			check_vaddr(f->esp+16);
			f->eax = sum_of_four_int((int)*(uint32_t *)(f->esp+4),(int)*(uint32_t *)(f->esp+8),(int)*(uint32_t *)(f->esp+12),(int)*(uint32_t *)(f->esp+16));
			break;
	}
	//  thread_exit ();
}
void halt (void){
	shutdown_power_off();
}

void exit (int status){
	int i;
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current()->exit_status = status;
	for(i=3;i<128;i++){
		if(thread_current()->fd[i] != NULL){
			close(i);
		}
	}
	thread_exit ();
}

pid_t exec (const char *cmd_line){
	return process_execute(cmd_line);
}

int wait (pid_t pid){
	return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size){
	unsigned i;
	int ret=-1;
	struct file *fp;
	check_vaddr(buffer);
	lock_acquire(&filesys_lock);
	if(fd==0){
		for(i=0;i<size;i++){
			if(((char *)buffer)[i] == '\0'){
				break;
			}
		}
		ret = i;
	}
	else if(fd>2){
		fp = thread_current()->fd[fd];
		if(fp == NULL)
			exit(-1);
		ret = file_read(fp, buffer, size);
	}
	lock_release(&filesys_lock);
	return ret;
}

int write (int fd, const void *buffer, unsigned size){
	int ret = -1;
	struct file *fp;
	check_vaddr(buffer);
	lock_acquire(&filesys_lock);
	if(fd == 1){
		putbuf(buffer, size);
		ret = size;
	}
	else if(fd>2){
		fp = thread_current()->fd[fd];
		if(fp == NULL){
			lock_release(&filesys_lock);
			exit(-1);
		}
		if(fp->deny_write)
			file_deny_write(fp);
		ret = file_write(fp, buffer, size);
	}
	lock_release(&filesys_lock);
	return ret;
}

void check_vaddr(const void *vaddr){
//	uint32_t pagedir = thread_current()->pagedir;
	if(!is_user_vaddr(vaddr)){
		exit(-1);
	}
	if(pagedir_get_page(thread_current()->pagedir, vaddr)==NULL){
		exit(-1);
	}
}

/* Project 2 */
bool create (const char *file, unsigned initial_size){
	if(file==NULL){
		exit(-1);
	}
	check_vaddr(file);
	return filesys_create(file, initial_size);
}

bool remove (const char *file){
	if(file==NULL)
		exit(-1);

	check_vaddr(file);
	return filesys_remove(file);
}

int open (const char *file){
	int i;
	int ret = -1;
	struct file *fp;
	if(file == NULL){
		exit(-1);
	}
	check_vaddr(file);
	lock_acquire(&filesys_lock);
	fp = filesys_open(file);
	if(fp==NULL)
		ret = -1;
	else{
		for (i=3;i<128;i++){
			if(thread_current()->fd[i] == NULL){
				if(strcmp(thread_current()->name, file) == 0)
					file_deny_write(fp);
				thread_current()->fd[i] = fp;
				ret = i;
				break;
			}
		}
	}
	lock_release(&filesys_lock);
	return ret;
}

void close (int fd){
	struct file *fp;
	if(thread_current()->fd[fd] == NULL)
		exit(-1);
	fp = thread_current()->fd[fd];
	thread_current()->fd[fd] = NULL;
	return file_close(fp);
}

int filesize (int fd){
	if(thread_current()->fd[fd] == NULL)
		exit(-1);
	return file_length(thread_current()->fd[fd]);
}

void seek (int fd, unsigned position){
	if(thread_current()->fd[fd] == NULL)
		exit(-1);
	file_seek(thread_current()->fd[fd], position);
}

unsigned tell (int fd){
	if(thread_current()->fd[fd] == NULL)
		exit(-1);
	return file_tell(thread_current()->fd[fd]);
}

/* Additional System Call Functions */

int sum_of_four_int(int a, int b, int c, int d){
	return a + b + c + d;
}

int fibonacci(int n){
	int a=0, b=1, c, i;
	if(n==0)
		return a;
	for(i=2;i<=n;i++){
		c = a+b;
		a=b;
		b=c;
	}
	return b;
}
