#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>
int
main (int argc, char *argv[]){
		int i, a[4];

		for(i=1;i<argc;i++)
				a[i] = atoi(argv[i]);

		printf("%d %d\n",fibonacci(a[1]),sum_of_four_int(a[1],a[2],a[3],a[4]));

		return EXIT_SUCCESS;
}
